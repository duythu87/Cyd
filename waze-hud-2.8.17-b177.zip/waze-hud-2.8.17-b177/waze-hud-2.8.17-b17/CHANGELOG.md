# Nhật Ký Thay Đổi (Changelog) - WazeHUD CYD 2.8"

Dự án WazeHUD tối ưu cho màn hình ESP32-2432S028 (CYD 2.8 inch). Toàn bộ firmware được phát hành dưới định dạng **Factory All-in-One** (đã bao gồm Bootloader, Partition Table và Firmware), nạp duy nhất 1 file tại offset **`0x0`**.

---

## [Build 17 (v2.8.17-b17)] - 2026-10-15

> [!NOTE]
> **Lời Cảm Ơn Tác Giả Gốc & Tuyên Bố Dự Án:**
> - Bản phát triển WazeHUD trên repository này là phiên bản cá nhân hóa, được xây dựng và tối ưu mở rộng hoàn toàn dựa trên sự hỗ trợ của **AI (Google Gemini / Antigravity)** với mục đích chính là phục vụ nhu cầu sử dụng thực tế trên xe của cá nhân mình và chia sẻ mã nguồn mở cho cộng đồng cùng tham khảo.
> - Xin trân trọng gửi lời cảm ơn chân thành và sâu sắc nhất tới **Tác giả gốc [ShindouAris (WazeHUD)](https://github.com/ShindouAris/WazeHUD)** cùng cộng đồng **[WazeMod Vietnam](https://wazemod.io.vn)** đã tạo nên nền tảng phần mềm tuyệt vời này!

> Bản phát hành B17 nâng cấp **HLP Device Config Schema Rev 8 (10 mục)** hỗ trợ chuyển đổi động chân đèn nền **GPIO 21 $\leftrightarrow$ 27** trực tiếp từ App, khôi phục **Biển báo giới hạn tốc độ To Cực Đại ($R = 60\text{ px}$)** ở mọi chế độ lái, tái cấu trúc tỷ lệ hàng màn hình ($142\text{px} - 26\text{px} - 72\text{px}$), tích hợp **Chế độ trượt chữ Marquee linh hoạt** cho thanh Đường hiện tại kết hợp hiển thị ETA cố định màu Cyan, loại bỏ chữ "TỰ DO" thừa thãi, và tự động gọt gọn chỉ dẫn `"Tiếp tục đi thẳng"` thành `"Đi thẳng"`.

### ⚙️ Nâng cấp Chuẩn Cài đặt HLP Device Config Schema Rev 8 (10 mục)
- **Mục 10 (`backlight_pin` - Chân đèn nền LCD, selection):**
  - Cho phép người dùng chuyển đổi chân đèn nền giữa **GPIO 21 (Mặc định)** và **GPIO 27 (Biến thể)** trực tiếp từ App WazeMod trên điện thoại.
  - Tương thích tức thì với mọi lô board màn hình ESP32-2432S028 trên thị trường, khắc phục triệt để tình trạng màn hình bị tối đen do khác chân backlight mà không cần phải chỉnh code nạp lại firmware.

### 🛑 Khôi phục Biển Giới Hạn Tốc Độ To Cực Đại ($R=60\text{ px}$) & Huy Hiệu Tốc Độ Lồng Tinh Tế
- **Khôi phục biển to cực đại:** Phóng to biển báo tốc độ lên kích thước cực đại (bán kính $R = 60\text{ px}$, đường kính $120\text{ px}$) ở cả chế độ Chạy Tự Do và Dẫn Đường Waze.
- **Huy hiệu tốc độ lồng ghép tinh tế (Nested Speed Badge):**
  - Cạnh ngoài cùng bên phải của huy hiệu ($W=38, H=28$) được căn trùng khớp hoàn hảo với cạnh ô vuông bao trùm biển báo giới hạn tốc độ ($signX + 60 = 194$, $badgeX = 156$).
  - Huy hiệu ăn sâu vào góc dưới bên phải của viền đỏ mà hoàn toàn không đè lấn số chỉ tốc độ ở tâm, đồng thời giải phóng tối đa không gian cho cụm bên phải.
- **Cân đối tỷ lệ cột bên trái (`leftColWidth = 72px`, tâm `cx = 36`):**
  - **Chạy tự do:** Chuyển đồng hồ sang font `kTextMedium` (cao 22px, ngang ~50px), căn giữa đều 2 lề 11px không còn bị cấn viền. Thứ ở $y = 16$, vạch kẻ ở $y = 74$, ngày tháng ở $y = 84$.
  - **Dẫn đường:** Căn giữa dọc và ngang đối xứng hoàn hảo cụm điều hướng. Mũi tên 60x60 đặt ở `assetX = 6, maneuverAssetY = 41` (vùng ink $y = 42 \dots 99$). Khoảng cách số mét font `kTextMedium` dời xuống $y = 102$ (vùng ink $y = 108 \dots 119$). Đảm bảo lề trên (cách banner) và lề dưới (cách đáy cụm) đều bằng đúng **$22\text{ px}$**, khoảng trống giữa icon và chữ đạt **$8\text{ px}$** thông thoáng.
  - **Vector fallback:** Đặt `top = 44, bottom = 97, roundaboutCenterY = 70, junctionY = 75, drawRoundaboutExit centerY = 70` bù trừ stroke thickness 5px giữ ink hoàn toàn trong phạm vi an toàn.
- **Tính nguyên tử & Rollback an toàn cho Chân đèn nền (Backlight Pin):**
  - Trong `DisplayDriver::setBacklightPin()`: Kiểm tra toàn bộ mã lỗi `ledc_stop()`, `gpio_reset_pin()`, `ledc_channel_config()` và `ledc_update_duty()`. Tự động rollback phần cứng về pin cũ nếu có lỗi, log `ESP_LOGE` và không thay đổi trạng thái driver/NVS khi cấu hình thất bại.
  - Trong `DeviceConfigManager::handleSetCommit()`: Rollback phần cứng an toàn kèm kiểm tra mã lỗi khi lưu NVS thất bại.
- **Khắc phục triệt để lỗi lẹm đỉnh biển báo:** Điều chỉnh thứ tự vẽ (layering) đưa banner tên đường tiếp theo ($y = 0 \dots 19$) vẽ trước, biển báo tròn đỏ to cực đại ($y = 20 \dots 140$) vẽ sau, đảm bảo hình tròn đỏ hiển thị hoàn hảo 100%, không bao giờ bị cắt vạt ngang.

### 🔔 Mở Rộng Cụm Cảnh Báo (`layout::Alerts`, $W=124\text{ px}$) & Nâng Cấp Hiển Thị 3 Biển Đồng Thời
- **Mở rộng cụm cảnh báo:** Tận dụng không gian sau khi thu gọn biển tốc độ, ranh giới `layout::Alerts` được mở rộng từ 95px lên **124px** (tăng thêm gần 30% bề ngang).
- **Hệ thống hiển thị cảnh báo theo chuẩn Quy tắc 3.2:**
  - **Khi không có phân làn (`laneCount == 0`):**
    - Cụm bên phải (`Alerts`) dành toàn bộ hiển thị **DUY NHẤT 1 Biển VIP ưu tiên cao nhất** to cực đại ($R=20$, font `kTextMedium` ở $y=84$).
    - Thanh đáy (`Guidance`) hiển thị các cảnh báo tiếp theo dưới dạng 1 đến 4 thẻ card rộng rãi, trực quan và không bao giờ lặp lại biển VIP ở trên.
  - **Khi có phân làn (`laneCount > 0`):**
    - Thanh đáy dành trọn vẹn cho mũi tên phân làn.
    - Cụm bên phải hiển thị linh hoạt 2 tầng: Tầng trên biển VIP $R=16$ ($y=40$); Tầng dưới: nếu có 1 biển phụ thì căn giữa ($R=13$), nếu có $\ge 2$ biển phụ thì hiển thị **song song 2 biển phụ nhỏ** ($R=13$, mỗi cột rộng 58px) giúp tài xế theo dõi đồng thời tới **3 biển cảnh báo** mà không bị sót.

### 🏷️ Thanh Đường Hiện Tại & ETA Trượt Marquee Linh Hoạt
- **Bên phải:** Cố định thông tin **`ETA 12:34`** (màu Cyan) rõ ràng, sắc nét.
- **Bên trái:** Hiển thị **`HT: [Tên đường hiện tại]`**.
- **Cơ chế trượt chữ Marquee linh hoạt:** Nếu tên đường dài vượt quá khoảng trống khả dụng (trừ đi phần ETA), chữ sẽ tự động trượt mượt mà 30 FPS. Nếu tên đường ngắn thì hiển thị tĩnh đứng yên, không bao giờ bị đè lấn sang phần ETA.

### 🧭 Tối giản Giao diện & Rút gọn Chỉ dẫn
- **Bỏ chữ "TỰ DO":** Loại bỏ hoàn toàn dòng chữ "TỰ DO" màu xanh lá cây ở đáy cột bên trái. Căn chỉnh lại khoảng cách Thứ $\rightarrow$ Giờ to $\rightarrow$ Đường phân cách $\rightarrow$ Ngày tháng năm giúp màn hình thoáng đãng, sang trọng.
- **Rút gọn chỉ dẫn:** Tự động phát hiện và rút gọn cụm `"Tiếp tục đi thẳng"` thành `"Đi thẳng"` (ví dụ: `"Tiếp tục đi thẳng trên QL1A"` $\rightarrow$ `"Đi thẳng trên QL1A"`), tiết kiệm không gian hiển thị, dễ đọc nhanh khi lái xe.

### 🚦 Tối Giản Cảnh Báo Kẹt Xe & Khắc Phục Triệt Để Giao Cắt Đồng Hồ / Vòng Severity
- **Tối giản hiển thị kẹt xe:** Loại bỏ số phút kẹt (`+%d PH`), chỉ hiển thị nhãn mức độ ùn tắc ngắn gọn (`NHẸ`, `VỪA`, `NẶNG`, `ĐỨNG IM`, `ĐƯỜNG ĐÓNG`), không bao giờ bị tràn biên ngang hay cấn viền.
- **Khắc phục giao cắt đồng hồ & vòng severity:** Đưa đồng hồ lên `clockY = 1` và vẽ sau cùng (overlay priority); thu gọn vòng severity biển 2 tầng thành $R = 18$ dày 1px, đảm bảo khoảng cách an toàn 4px so với đồng hồ, triệt tiêu 100% hiện tượng xước/mất nét số giờ.
- **Hệ tọa độ dọc đồng bộ 4 scanlines clearance:** Đặt biển chính $y = 35$, số mét $y = 53$, nhãn kẹt xe $y = 68$, icon phụ $y = 102$, số mét phụ $y = 121$. Mọi tầng hiển thị đều có khoảng trống an toàn $\ge 4\text{ px}$.

### 🎨 Tinh Chỉnh Cân Đối Bố Cục Chạy Tự Do & Hạ Biển Báo Giới Hạn Tốc Độ
- **Header chạy tự do cân đối 3 phần:** Thứ căn trái (`kTextMedium`, Cyan), Ngày tháng năm căn giữa (`dd/mm/yyyy`, Trắng), Giờ phút căn phải (`hh:mm`, Trắng) trải đều toàn bộ chiều rộng 320 px.
- **Thanh đường hiện tại:** Luôn thêm tiền tố `"HT: "` và căn lề trái tại $x = 8$, tự động trượt chữ marquee nếu tên đường dài.
- **Cân đối khoảng hở biển báo:** Tinh chỉnh bán kính biển báo $R = 58\text{ px}$, tâm `signY = 82`, ô tốc độ `badgeY = 112`, tạo khoảng hở thoáng đãng 4px so với đường tiếp theo ở trên và phẳng hàng ngang cách 2px với đường hiện tại ở dưới.
- **Lược bỏ pin:** Loại bỏ hoàn toàn khối vẽ pin trên CYD 2.8" (do thiết bị dùng nguồn 5V USB trực tiếp trên xe).

### 📦 Danh Mục Firmware Đóng Gói Bản Build 17
Toàn bộ file firmware phát hành được lưu trữ tại thư mục [`releases/`](file:///d:/waze-hud-CYD2.8-V2USB/releases):
- **`CYD2.8-BLE-b17-161026_1546_full.bin`** (1.981.424 bytes): Bản Factory Full Flash nạp qua cáp USB trên máy tính từ offset duy nhất `0x0`.
- **`CYD2.8-BLE-b17-161026_1546_app.bin`** (1.850.352 bytes): Bản WiFi Web OTA nạp không dây trực tiếp từ trình duyệt điện thoại (`0xE9` header).

---

## [Build 16 (v2.8.16-b16)] - 2026-10-14

> [!NOTE]
> **Lời Cảm Ơn Tác Giả Gốc & Tuyên Bố Dự Án:**
> - Bản phát triển WazeHUD trên repository này là phiên bản cá nhân hóa, được xây dựng và tối ưu mở rộng hoàn toàn dựa trên sự hỗ trợ của **AI (Google Gemini / Antigravity)** với mục đích chính là phục vụ nhu cầu sử dụng thực tế trên xe của cá nhân mình và chia sẻ mã nguồn mở cho cộng đồng cùng tham khảo.
> - Xin trân trọng gửi lời cảm ơn chân thành và sâu sắc nhất tới **Tác giả gốc [ShindouAris (WazeHUD)](https://github.com/ShindouAris/WazeHUD)** cùng cộng đồng **[WazeMod Vietnam](https://wazemod.io.vn)** đã tạo nên nền tảng phần mềm tuyệt vời này!

> Bản phát hành B16 đánh dấu bước tiến lớn với tính năng **Cập nhật Không dây WiFi Web OTA qua màn hình cảm ứng**, làm mới toàn diện **Giao diện Chế độ Chạy Tự Do (Free Drive)** với bộ Lịch vạn niên & Đồng hồ to 30px, **Biển giới hạn tốc độ thích ứng thông minh** (to khi chạy tự do, gọn gàng khi dẫn đường), **Dải tên đường tiếp theo nổi bật trên nền đen** mở rộng gấp đôi chiều rộng hiển thị (215px), và chuẩn hóa toàn bộ file firmware vào thư mục `releases/release_b16/` với quy chuẩn đặt tên timestamp ngày_giờ.

### 📦 Danh mục Firmware Phát hành B16
Toàn bộ firmware bản B16 được lưu trữ tập trung tại thư mục [`releases/release_b16/`](file:///workspaces/waze-hud/releases/release_b16):
- **`CYD2.8-BLE-141026-b16_full.bin`**: Bản Bluetooth BLE nạp Full Flash từ offset `0x0` qua cáp USB trên máy tính (hợp nhất 1-USB và 2-USB).
- **`CYD2.8-BLE-141026-b16_app.bin`**: Bản Bluetooth BLE dùng để nạp trực tiếp không dây từ điện thoại qua Web OTA.
- **`CYD2.8-USB-141026-b16.bin`**: Bản cắm cáp USB Serial 115200 cho màn 2.8" (hợp nhất 1-USB và 2-USB, nạp Full Flash offset `0x0`).

### 🚀 Cập nhật Không Dây WiFi Web OTA qua Màn Hình Cảm Ứng
- **Thao tác 2 bước an toàn (Anti-accidental trigger):** Chạm giữ màn hình (hoặc nút BOOT trên mạch) 3 giây $\rightarrow$ hiển thị modal xác nhận đếm ngược 6 giây kèm thanh tiến trình $\rightarrow$ chạm giữ tiếp 3 giây để xác nhận vào chế độ WiFi OTA.
- **Trạm phát sóng độc lập (SoftAP Hotspot):** HUD tự động phát WiFi `WazeHUD-OTA` (mật khẩu: `12345678`), mở Web Server nạp file tại địa chỉ `http://192.168.4.1`.
- **Giao diện Dark Mode cao cấp trên trình duyệt:** Cho phép người dùng chọn trực tiếp file `.bin` (`_app.bin`) từ điện thoại (iOS / Android) và nhấn "Bắt đầu Cập nhật" ngay trên xe mà không cần tháo HUD hay cắm máy tính.
- **Đồng bộ tiến trình nạp (Real-time Progress):** Thanh tiến trình và tỷ lệ % nạp flash hiển thị trực tiếp đồng thời trên cả trình duyệt điện thoại lẫn màn hình HUD.
- **An toàn tuyệt đối:** Tự động giải phóng tài nguyên BLE khi nạp, đếm ngược 180s tự thoát về HUD nếu không có thao tác, tự động khởi động lại sau khi nạp thành công.

### 🕒 Làm mới Giao diện Chế độ Chạy Tự Do (Free Drive Mode)
- **Cột bên trái ($84\text{ px}$):** Thay thế cụm biểu tượng la bàn & chữ "CHẠY TỰ DO" cũ bằng bộ Lịch & Đồng hồ tiện ích Việt hóa đầy đủ:
  - **Dòng 1:** Thứ trong tuần (font `kTextSmall`, màu Cyan: `CHỦ NHẬT`, `THỨ HAI`, `THỨ BA`, `THỨ TƯ`, `THỨ NĂM`, `THỨ SÁU`, `THỨ BẢY`).
  - **Dòng 2:** Giờ : Phút (font `kTextLarge` số to **30px**, màu Trắng sắc nét, cập nhật theo từng phút).
  - **Dòng 3:** Đường phân cách mờ tinh tế.
  - **Dòng 4:** Ngày/Tháng/Năm (font `kTextSmall`, màu Trắng: `DD/MM/YYYY`).
  - **Dòng 5:** Nhãn trạng thái `TỰ DO` (font `kTextSmall`, màu Xanh lá).
- **Tự động ẩn đồng hồ nhỏ góc trên bên phải:** Khi chạy tự do, đồng hồ phụ ở góc cụm cảnh báo tự động ẩn để tránh hiển thị trùng lặp 2 đồng hồ trên một màn hình. Khi bắt đầu lộ trình dẫn đường Waze, đồng hồ góc phải tự động hiển thị lại.

### 🛑 Biển Giới Hạn Tốc Độ Thích Ứng Thông Minh (Adaptive Speed Sign)
- **Khi Chạy Tự do:** Không có dải tên đường tiếp theo ở trên $\rightarrow$ Giữ nguyên biển báo tốc độ **To Cực Đại** ($R = 60\text{ px}$, $r = 50\text{ px}$, tâm $y = 62$).
- **Khi Dẫn đường Waze:** Tự động chuyển sang kích thước gọn gàng ($R = 48\text{ px}$, $r = 40\text{ px}$, tâm $y = 72$) nhưng **giữ nguyên kích thước chữ số to đậm** (`kNumberSpeedLimit` size 48 cho 2 số, size 36 cho 3 số). Nhường dải đen $y = 0..26$ phía trên cho tên đường tiếp theo mà không làm lẹm hay cắt xén biển báo.
- **Chế độ Ban đêm (Night Mode):** Nền biển đen (`colors::Panel`), chữ số trắng (`colors::White`), viền đỏ (`colors::Red`) tương thích hoàn hảo và liền lạc tuyệt đối với giao diện tổng thể.

### 🏷️ Tên Đường Tiếp Theo Nổi Bật Trên Dải Nền Đen (Next Street Overlay Banner)
- Dải banner trên cùng ($y = 0..26$) phủ nền đen phẳng, chữ trắng (`colors::White`) sắc nét.
- **Mở rộng chiều rộng hiển thị khả dụng từ 105px $\rightarrow$ 215px (gấp đôi):** Hầu hết các tên đường tiếng Việt phổ biến hiển thị tĩnh trọn vẹn tức thì, không cần cuộn chữ. Chỉ các tên đường siêu dài (> 215px) mới cuộn marquee êm ái với tốc độ 30 FPS.

---

## [Build 15 (v2.8.15-b15)] - 2026-10-13

> Bản phát hành B15 tối ưu hóa toàn bộ hệ sinh thái firmware về **3 file BIN tinh gọn**, nâng cấp chuẩn cấu hình **HLP Device Config Schema Rev 7** (bổ sung Cố định độ sáng và Đảo ngược màu màn hình tích hợp 2USB & 1USB), thang màu số mét biển báo 4 cấp độ, giảm độ sáng đêm về 20%, tên đường kế tiếp trượt dưới biển báo tốc độ và sửa triệt để lỗi bootloop trên bản 3.5".

### 📦 Tinh gọn & Thống nhất còn đúng 3 Firmware Factory duy nhất (Offset 0x0)
- **`CYD2.8-BLE-131026-b15.bin`**: Bản Bluetooth BLE cho màn 2.8" (Tích hợp cả bản 2-USB và 1-USB làm 1 firmware duy nhất nhờ tính năng Đảo ngược màu).
- **`CYD2.8-USB-131026-b15.bin`**: Bản cắm cáp USB Serial 115200 cho màn 2.8" (Tích hợp cả bản 2-USB và 1-USB).
- **`CYD3.5-BLE-131026-b15.bin`**: Bản Bluetooth BLE cho module ESP32-S3 3.5" ST77922 QSPI 480×320 (đã sửa dứt điểm lỗi bootloop).

### ⚙️ Nâng cấp Chuẩn Cài đặt HLP Device Config Schema Rev 7 (9 mục)
- **Mục 1 (`fixed_brightness` - Cố định độ sáng, toggle):**
  - Khi **ON**: Mở khóa Mục 2 (`brightness`) cho phép chỉnh độ sáng tùy ý từ App, độ sáng này sẽ giữ cố định và ưu tiên cao hơn chế độ tự động theo giờ.
  - Khi **OFF**: Khóa Mục 2 và tự động hoàn trả độ sáng theo khung giờ thực tế (100% ban ngày / 20% ban đêm).
- **Mục 4 (`invert_color` - Đảo ngược màu, toggle):**
  - Đảo cực tính màn hình LCD phần cứng (`INVOFF` / `INVON`), cho phép người dùng dùng mạch CYD 1-USB hay 2-USB đều hiển thị chuẩn màu trên cùng một file firmware.

### 🌙 Giảm độ sáng ban đêm về 20%
- Trong khung giờ từ **19:00 đến 05:00 sáng**, HUD tự động hạ độ sáng về mức **20%** (thay vì 30% trước đây) giúp chống chói mắt tối đa khi lái xe ban đêm.

### 🎨 Thang màu khoảng cách biển báo 4 cấp độ trực quan
- **`> 600m`**: Màu xanh lá cây (`Green`) - Khoảng cách còn xa, trạng thái an toàn.
- **`300m – 600m`**: Màu trắng (`White`) - Đang tiến lại gần cảnh báo.
- **`100m – 300m`**: Màu cam vàng (`Amber`) - Cảnh giác, sẵn sàng giảm tốc độ.
- **`< 100m`**: Màu đỏ tươi (`Red`) - Rất gần vị trí cảnh báo / điểm bắn tốc độ.

### 🚗 Tên đường tiếp theo trượt mượt mà 30 FPS dưới biển báo tốc độ (Smooth Marquee)
- **Hợp nhất Canvas Nguyên tử (`MainCluster` $225 \times 130\text{ px}$):** Ghép cụm Điều hướng (Maneuver) và Cụm tốc độ (SpeedCluster) thành một vùng vẽ liền mạch duy nhất. Loại bỏ hoàn toàn đường cắt vạch dọc cũ ($x = 85$ và $x = 122$) và hiện tượng xé hình/giật khựng khi chữ đi qua điểm nối.
- **Hiệu ứng trượt lọt tự nhiên:** Tên đường kế tiếp vươn dài từ $x = 5$ chạy thẳng một mạch và lọt êm ái dưới đường viền tròn của biển báo tốc độ ($R = 60$).
- **Nâng tốc độ animation lên ~30 FPS:** Giảm chu kỳ tick UI từ 80ms xuống **35ms**, giảm thời gian dịch từ 45ms/px xuống **28ms/pixel**, rút ngắn thời gian dừng đọc đầu/cuối còn **1.0s / 0.5s** giúp trải nghiệm trượt chữ cực kỳ thanh thoát và êm ái.

### 🛠️ Sửa lỗi Bootloop trên phiên bản 3.5" (ESP32-S3)
- Bật cờ `CONFIG_SPIRAM_IGNORE_NOTFOUND=y` chống crash `abort()` khi khởi động trên board dùng Quad PSRAM hoặc không có PSRAM.
- Cung cấp cơ chế fallback an toàn cho bộ đệm vẽ DMA, chống tràn RAM DMA khi NimBLE chạy đồng thời.

### 🔌 Khắc phục Triệt để Lỗi Phân làn & Cài đặt App trên bản USB Serial (`CYD2.8-USB`)
- **Bổ sung bản tin HLP `dev` opt-in phân làn:** Khắc phục lỗi Waze Mod không gửi dữ liệu làn đường (`lan`) và chỉ gửi 1 cảnh báo (`alr`) do thiếu bản tin khai báo thiết bị `dev` trên kết nối Serial. Bổ sung cơ chế phát `dev` an toàn khi khởi động và theo phiên `sess` mới, chặn đứng nguy cơ lặp vô tận `dev` ↔ `hi`.
- **Nâng bộ đệm TX UART lên 2048 byte:** Đảm bảo nạp và phát trọn bộ 11 gói schema cài đặt HLP Device Config (~1.2 KB) tức thì, loại bỏ hoàn toàn hiện tượng nghẽn luồng CPU khi Waze Mod kết nối hoặc mở giao diện cài đặt trên App.

---

## [Build 14 (v2.8.14-b14)] - 2026-10-08

> Bản phát hành B14 nâng cấp toàn diện hệ thống hiển thị mũi tên làn đường chếch 45° (Slight Left / Right) với đường cong uốn lượn mềm mại, căn giữa chuẩn xác, cơ chế render phân lớp Z-Order và khắc phục triệt để lỗi bắt tay giao thức/cài đặt trên ứng dụng điện thoại.

### ⚡ Khắc phục lỗi Giao thức & Cài đặt App (Hotfix Protocol & App Settings - ĐẶT LÊN ĐẦU)
- **Khắc phục triệt để lỗi App không chỉnh được cài đặt & Làn đường không nhảy:**
  - **Xóa bỏ vòng lặp vô tận Handshake `dev` ↔ `hi`:** Loại bỏ hoàn toàn khối kiểm tra sai trường trong bản tin `hi`, chấm dứt tình trạng HUD và app liên tục gửi lại khai báo khiến dữ liệu dẫn đường (`lan` và cảnh báo) bị nghẽn và xóa trắng liên tục.
  - **Làn đường nhảy tức thì:** Khôi phục luồng nhận dữ liệu điều hướng mượt mà, màn hình chuyển sang cụm mũi tên chỉ dẫn làn ngay khi có thông tin từ Waze, không còn bị đơ ở ETA.
  - **Cài đặt trên App phản hồi tức thì:** Xóa bỏ độ trễ thừa trong lệnh gửi JSON cấu hình và tối ưu hóa hàng đợi BLE giúp app Waze Mod gửi/lưu cài đặt (độ sáng, giao diện Ngày/Đêm, xoay màn hình...) phản hồi ngay lập tức, không còn báo lỗi transaction timeout.
  - **Đồng bộ trên trọn bộ 5 biến thể firmware** (CYD 2.8" 2-USB BLE, 1-USB BLE, 2-USB Serial, 1-USB Serial và CYD 3.5").

### 🏹 Cải tiến Đồ họa Mũi tên Làn đường (Lane Graphics Redesign)
- **Thân mũi tên rẽ chếch 45° uốn cong mềm mại (Smooth Curved Arrows):** Thay thế các đường gấp khúc thô cứng bằng đường cong uốn lượn nhẹ tự nhiên (Quad Curve) theo phong cách Waze; thân đi thẳng giữ trục đứng cân đối.
- **Đầu mũi tên vát Chevron thanh thoát:** Thiết kế cánh mũi tên góc $\pm 48^\circ$ kèm đuôi vát khí động học (Chevron notch), ôm khít đỉnh cung cong.
- **Căn giữa chuẩn xác:** Làn đơn rẽ chếch trái (`0x02`) và chếch phải (`0x10`) được căn chỉnh đối trọng trục gốc, nằm cân đối tuyệt đối ngay tâm làn.
- **Tách biệt tổ hợp Rẽ chếch 45° + Vuông góc 90° (`0x30`, `0x06`):** Nhánh 45° vươn lên đỉnh cao nhất, nhánh rẽ 90° tách ra từ bụng dưới, cách nhau 30px, không còn bị chen chúc.
- **Cơ chế render Two-Pass phân lớp Z-Order:** Vẽ toàn bộ các nhánh không chọn (màu xám) xuống dưới nền trước, sau đó vẽ đè nhánh được chọn (màu trắng) lên trên. Loại bỏ hoàn toàn việc màu xám đè lên hoặc cắn khuyết nhánh màu trắng tại các điểm giao cắt.
- **Hỗ trợ đầy đủ các tổ hợp làn phức tạp:** Làn Thẳng + Chếch (`0x03`, `0x11`), Chạc đôi chữ Y (`0x12`), Làn 3 hướng (`0x13`, `0x25`).

---

## [Beta 8 (v2.8.8)] - 2026-10-06

> Bản cập nhật lớn toàn diện tối ưu hóa trải nghiệm lái xe thực tế, nâng cấp cụm tốc độ taplo và chế độ chạy tự do so với bản Beta 7 (v2.8.2 phát hành ngày 05/10/2026).

### 🛑 Thiết kế lại cụm tốc độ Taplo hiện đại (Redesigned Speed Cluster)
- **Biển báo giới hạn tốc độ cỡ đại:** Phóng to vòng tròn biển báo tốc độ lên mức tối đa với bán kính **$R = 60\text{ px}$** (đường kính **$120\text{ px}$**), viền đỏ 100% đỏ cờ dày $10\text{ px}$, số bên trong to đậm nét giúp tài xế quan sát cực kỳ rõ ràng từ khoảng cách xa trên taplo.
- **Bỏ chữ "km/h" rườm rà:** Loại bỏ chữ km/h dưới số tốc độ giúp giao diện thoáng đãng, hiện đại, loại bỏ chi tiết thừa gây phân tâm khi lái xe.
- **Huy hiệu tốc độ xe thông minh ($38 \times 28\text{ px}$):** Tốc độ thực tế của xe được thu nhỏ số lại cho tinh tế và đặt gọn gàng trong huy hiệu bo góc tại góc dưới bên phải biển giới hạn ($x=100, y=100$).
- **Khắc phục lỗi tràn viền khi chạy tốc độ cao (> 100 km/h):** Khi xe chạy trên cao tốc ở tốc độ 3 chữ số (105, 115, 120 km/h), chữ số tự động chuyển sang cỡ vừa vặn nằm hoàn toàn bên trong huy hiệu, tuyệt đối không bao giờ lấn sang cột cảnh báo bên phải hay che mất đồng hồ.

### 🧭 Chế độ Chạy Tự Do hiển thị tối đa cảnh báo (Smart Free Drive Mode)
- **Tận dụng 100% dải đáy màn hình ($320 \times 82\text{ px}$):** Khi không cài lộ trình dẫn đường (chế độ chạy tự do), dải băng phía dưới tự động hiển thị đồng thời lên đến **4 thẻ cảnh báo độc lập** (Camera phạt nguội, Camera đèn đỏ, Điểm bắn tốc độ, Cảnh báo giao thông...).
- **Cảnh báo Quá Tốc Độ kích hoạt ở mọi chế độ lái:** Gỡ bỏ giới hạn chỉ cảnh báo khi có lộ trình dẫn đường. Giờ đây khi xe vượt tốc độ giới hạn (cả khi dẫn đường và khi chạy tự do), viền đỏ nhấp nháy toàn màn hình (2 Hz) và huy hiệu tốc độ xe chuyển sang nền đỏ rực cảnh báo sẽ luôn hoạt động chuẩn xác.

### 🎨 Tinh chỉnh độ nét đồ họa (Pixel-Perfect Graphics)
- **Khắc phục lỗi mờ/vỡ nét mũi tên phân làn:** Làm mượt các góc cua 90 độ và góc cua chữ U của mũi tên dẫn đường bằng thuật toán điền đầy hình tròn (fillCircle) tại các khớp nối. Các nét vẽ giờ đây sắc nét, mạch lạc và không còn hiện tượng răng cưa trên màn hình 320x240.
- **Biểu tượng Maneuver sắc nét:** Đảm bảo toàn bộ hệ thống biểu tượng chỉ đường (rẽ trái, phải, vòng xuyến) render chính xác từng pixel, mang lại trải nghiệm thị giác cao cấp.

### 📡 Ổn định kết nối & Hiệu năng hệ thống
- **Tương thích hoàn hảo WazeMod Android:** Cập nhật logic xử lý kết nối, đảm bảo kết nối Bluetooth BLE và USB Serial luôn duy trì liên tục và ổn định. Khắc phục triệt để hiện tượng thiết bị tự ngắt kết nối sau khi ghép nối thành công.

### 📦 Phát hành đồng bộ 4 biến thể phần cứng CYD 2.8" (Factory Offset 0x0)
1. **`waze_hud_cyd_28_factory.bin`**: Dành cho CYD 2.8" (2 Cổng USB) kết nối Bluetooth BLE.
2. **`waze_hud_cyd_28_1usb_factory.bin`**: Dành cho CYD 2.8" (1 Cổng Micro USB) kết nối Bluetooth BLE (đã cấu hình đảo màu & xoay chuẩn mạch 1 cổng).
3. **`waze_hud_cyd_28_usb_factory.bin`**: Dành cho CYD 2.8" (2 Cổng USB) cắm cáp USB Serial CH340.
4. **`waze_hud_cyd_28_1usb_serial_factory.bin`**: Dành cho CYD 2.8" (1 Cổng Micro USB) cắm cáp USB Serial UART.

---

## [v2.8.2] - 2026-10-05

- **Cảnh báo Đèn giao thông mới (Traffic Light Alert - Mã 75):** Bổ sung `AlertKind::TrafficLight = 75` đồng bộ với WazeMod APK, thiết kế icon pill-shape 3 bóng Đỏ - Vàng - Xanh.
- **Lưu giữ làn đường thông minh theo vận tốc (Speed-Aware Lane Retention):** Tạm dừng đếm ngược 15s khi tốc độ < 10 km/h để giữ nguyên chỉ dẫn làn khi dừng đèn đỏ hoặc kẹt xe.

