# Tổng quan nhanh dự án WazeHUD

> Cập nhật: 2026-09-24 · Branch hiện tại: `CYD2.82USB` (CYD mặc định) · ESP-IDF 5.5.5

WazeHUD là firmware ESP32 nhận dữ liệu dẫn đường Waze qua BLE/HLP/1 và hiển thị HUD ô tô có độ trễ thấp. Mã nguồn ứng dụng nằm trong `waze-hud/`; assets gốc nằm trong `assets/` và được chuyển thành dữ liệu nhúng để ESP32 không phải giải mã PNG/font khi chạy.

## Trạng thái quan trọng

- Branch `CYD2.82USB` dành riêng cho ESP32-2432S028 và build mặc định cho target `esp32`.
- Backend CYD dùng ILI9341, SPI2 40 MHz, BGR, `INVON` và xoay dirty stripe từ landscape native 320×240 sang panel native 240×320; font/icon giữ tỉ lệ pixel 1:1.
- Board có flash 4 MB, không PSRAM; partition table mặc định đã thu về hai OTA slot 1856 KiB.
- Build phần mềm đã thành công; màu, orientation, BLE và độ ổn định vẫn cần xác nhận trên phần cứng.
- Mốc code hiện tại là commit `85853d6` (`fix: black screen`).

## Phần cứng và Cấu hình Driver phân biệt phiên bản

| Thông số / Driver | Tree `CYD2.82USB` | Tree `2.81USB` |
|---|---|---|
| **Mục đích & Tên nhánh** | Phiên bản chính thức v2.8.2 | Phiên bản phát triển v2.8.1 |
| **Mã phiên bản (Firmware Version)** | **v2.8.2** (`PROJECT_VER = "2.8.2"`) | **v2.8.1** (`PROJECT_VER = "2.8.1"`) |
| **Hiển thị màn hình chờ** | `WazeHUD v2.8.2` | `WazeHUD v2.8.1` |
| **Thông tin thiết bị BLE (`fwv`)** | Báo `fwv: "2.8.2"` cho WazeMod | Báo `fwv: "2.8.1"` cho WazeMod |
| **Mạch mục tiêu (Target Board)** | ESP32-2432S028 (CYD 2.8" ILI9341) | ESP32-2432S028 (CYD 2.8" ILI9341) |
| **Driver Màn hình (LCD Driver)** | `esp_lcd_ili9341` SPI2 @ 40 MHz, BGR | `esp_lcd_ili9341` SPI2 @ 40 MHz, BGR |
| **Cấu hình Đảo màu (Color Invert)** | `INVOFF` (`esp_lcd_panel_invert_color = false`) | `INVON` (`esp_lcd_panel_invert_color = true`) |
| **Cơ chế xoay (Rotation Transform)**| Phần mềm: Dirty-stripe transpose (320×240 ➔ 240×320) | Phần mềm: Dirty-stripe transpose (320×240 ➔ 240×320) |
| **Sơ đồ chân LCD (Pinout)** | MOSI: 13, MISO: 12, SCLK: 14, CS: 15, DC: 2 | MOSI: 13, MISO: 12, SCLK: 14, CS: 15, DC: 2 |
| **Driver Đèn nền (Backlight Driver)**| GPIO 21 (LEDC PWM 5 kHz, Tự động Ngày/Đêm) | GPIO 21 (LEDC PWM 5 kHz, Tự động Ngày/Đêm) |
| **Driver Giao tiếp (Transport)** | Bluetooth Low Energy (BLE Server, HLP/1 4 Hz) | Bluetooth Low Energy (BLE Server, HLP/1 4 Hz) |
| **Driver LED RGB sau lưng** | GPIO 4 (R), 16 (G), 17 (B) - Chạy bình thường: TẮT | GPIO 4 (R), 16 (G), 17 (B) - Chạy bình thường: TẮT |
| **Driver Nút cứng (Button)** | GPIO 0 (BOOT, active-low, đa tác vụ 1/2/giữ) | GPIO 0 (BOOT, active-low, đa tác vụ 1/2/giữ) |
| **Cấu hình Flash & Phân vùng** | 4MB Flash (DIO 40MHz, 2 OTA slot 1856 KB) | 4MB Flash (DIO 40MHz, 2 OTA slot 1856 KB) |

## Kiến trúc

```text
Điện thoại / Waze Mod
        │ BLE GATT
        ▼
NimBLE transport ── bounded queue ──► HLP protocol task
                                            │
                                  framing + JSON decode
                                            ▼
                                  HudStateStore snapshot
                                            │
                                            ▼
                         dirty-region renderer + embedded assets
                                            │
                                            ▼
                                  display driver RGB565
```

Các module chính:

| Đường dẫn | Trách nhiệm |
| --- | --- |
| `main/bluetooth/` | BLE GATT, advertising, write/notify và reconnect |
| `main/protocol/` | HLP framing, handshake, heartbeat và decode state |
| `main/state/` | Snapshot HUD cố định dung lượng, truyền an toàn giữa task |
| `main/display/` | Layout, renderer, font và driver LCD theo profile |
| `main/config/` | Cấu hình động, validation và lưu NVS |
| `main/system/` | Pin, RSSI Bluetooth và trạng thái hệ thống |
| `main/assets/` | RGB565, alpha mask và font đã generate |

BLE callback chỉ sao chép dữ liệu vào queue. JSON, cập nhật state và truyền LCD chạy ngoài callback. Renderer chỉ vẽ lại vùng bị thay đổi, không redraw toàn màn hình theo mỗi state.

## Khả năng hiện có

- Nhận HLP/1 qua BLE, frame tối đa 512 byte, xử lý BLE chunk tùy ý.
- Gửi `dev`, trả lời `ping/pong`, kiểm tra UTF-8 và bỏ frame lỗi an toàn.
- Hiển thị tốc độ, biển giới hạn, hướng rẽ, vòng xuyến/lối ra, tối đa 10 làn đường, ETA, tên đường Việt Nam và cảnh báo; đầu mũi tên lane dùng asset Waze, hàng guidance nằm trên tên đường với ETA bên trái, còn `alrs` thứ 2/3 nằm ngay dưới cảnh báo chính.
- Tên đường dài chạy marquee; đồng hồ có dấu `:` nhấp nháy theo giây.
- Cảnh báo gần dưới 500 m đổi màu khoảng cách sang xanh.
- LED RGB phía sau đổi màu liên tục khi chưa kết nối, xanh dương khi chờ state, TẮT ở tốc độ bình thường (chống chói mắt ban đêm) và nháy đỏ 2 Hz khi quá tốc độ.
- Tự động điều chỉnh độ sáng Ngày / Đêm theo thời gian thực (100% ban ngày, 30% ban đêm).
- Nền đen tuyệt đối OLED-style (`0x0000`), viền đỏ tươi bão hòa 100% (`0xF800`) cho biển báo giới hạn và biển cấm.
- Biển báo cảnh báo phóng to 60×60 px, số mét khoảng cách cảnh báo và khoảng cách rẽ nâng cấp lên font `kTextMedium` (22 px), mũi tên rẽ đẩy lên cao (`y=16`).
- Gỡ bỏ Boot Logo tiết kiệm 27.6 KB Flash ROM, căn giữa màn hình chờ, ẩn biểu tượng Bluetooth/vạch sóng trên HUD chính.
- Hỗ trợ mirror HUD (nhấn đúp BOOT), xoay 180° (nhấn đơn), độ sáng, theme, offset và ngưỡng quá tốc độ lưu trong NVS.
- Cấu hình `Hien thi toc do` cho phép giữ tốc độ xe làm chính hoặc dùng biển giới hạn lớn làm chính với tốc độ xe nhỏ ở góc dưới-phải.
- KEY hiển thị trạng thái pin/BLE và đổi hướng màn hình theo cấu hình phần cứng.
- Mock mode chạy UI không cần điện thoại.

## Build nhanh

Kích hoạt ESP-IDF trên máy Windows hiện tại:

```powershell
. 'C:\Espressif\tools\Microsoft.v5.5.5.PowerShell_profile.ps1'
Set-Location D:\Code\WazeHUD\waze-hud
```

Build CYD 2.8 trên branch này:

```powershell
idf.py -B build build
```

Build mock CYD:

```powershell
idf.py -B build-mock `
  -D SDKCONFIG=sdkconfig.mock `
  -D "SDKCONFIG_DEFAULTS=sdkconfig.defaults;sdkconfig.mock.defaults" `
  build
```

## Firmware phân phối

Các file đã đóng gói nằm trong `waze-hud/dist/`. Bản tối ưu CYD hiện tại là R2:

| File | Cách dùng |
| --- | --- |
| `WazeHUD-CYD28-V10-25082026-20260907-R2-Factory.bin` | Flash tại offset `0x0`; gồm bootloader, partition table, OTA data và app |
| `WazeHUD-CYD28-V10-25082026-20260907-R2-OTA.bin` | App image; dùng với đúng partition table, app offset `0x20000` |
| `WazeHUD-CYD28-V10-25082026-20260907-R2-SHA256.txt` | Hash kiểm tra tính toàn vẹn |

Factory BIN phù hợp để cài mới hoặc khôi phục. OTA BIN không được flash tại `0x0`.

## Việc cần xác nhận tiếp

1. Flash mock profile lên đúng board ESP32-2432S028 để xác nhận màu BGR, orientation, backlight và software transpose.
2. Kết nối Waze Mod để xác nhận BLE/HLP trong lúc LCD SPI hoạt động.
3. Chạy mock lâu để kiểm tra dirty-region, marquee và biến đổi mirror/rotation.

## Tài liệu liên quan

- `README.md`: mô tả firmware CYD và HLP/1.
- `waze-hud/DISPLAY_CYD_28_PORTING.md`: pin map, build và checklist xác nhận CYD 2.8 inch.
- `waze-hud/FLASH_FIRMWARE_VI.md`: hướng dẫn flash bằng tiếng Việt.
- `waze-hud-link-sdk-ai-bundle.md`: đặc tả HLP/1 nguồn chuẩn.
- `waze-hud/main/Kconfig.projbuild`: display profile và tùy chọn build.
